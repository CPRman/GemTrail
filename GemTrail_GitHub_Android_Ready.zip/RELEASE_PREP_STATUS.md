GemTrail v1.2 release preparation: source-only, uncompiled, unsigned. Build workflow, API 36 target, drafts and checklist added. Developer account not verified. No Play Console submission made.
