# GemTrail Privacy Policy — DRAFT, NOT YET PUBLISHED
Effective date: [ADD DATE]  |  Developer: Gem Stone Wood  |  Contact: [ADD SUPPORT EMAIL]

GemTrail stores saved mineral waypoints (including names, coordinates and notes) and Trail Friends email contacts locally on your device. GemTrail does not currently operate a user-account or community server, and does not automatically upload your saved coordinates or friend contacts. CSV export and email actions share information only when you choose to use your device's share sheet or email app. Email messages are sent through your selected email provider, under that provider's privacy practices.

Opening Google Maps or the Gem Stone Wood Etsy store transfers you to those third-party services, which may collect data according to their own policies. The app currently has no in-app payment or donation processing. Offline coordinate plotting does not require internet access.

To delete locally stored GemTrail data, uninstall the app. [Confirm whether any other deletion controls are added before publishing.] We do not knowingly collect children's personal information through a GemTrail server. Rocks for Kids is educational content; parental supervision is encouraged.

We may revise this policy as functionality changes, including if account systems, analytics, crash reporting, location services, community features, or payments are added. Before publication, verify every statement against the final built APK/AAB and third-party SDKs.

Contact: [ADD SUPPORT EMAIL]
