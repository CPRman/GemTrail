# GemTrail — Google Play listing draft

**App name:** GemTrail

**Short description (draft):** Save mineral finds, explore UV crystals, and connect with rockhounds.

**Full description (draft):**
GemTrail by Gem Stone Wood helps rockhounds and curious explorers keep track of their mineral discoveries. Save mineral waypoints privately on your device, import and export finds using CSV files, and view your saved locations on an offline coordinate plot. Browse guides to minerals and fluorescent UV stones, explore Rocks for Kids, and email fellow rockhounds through your phone's email app. Visit the Gem Stone Wood Etsy shop for jade, crystals, and jewelry.

**Important:** Offline mode plots saved coordinates; it does not provide offline roads, topographic maps, live GPS navigation, or emergency services. Friend communication requires a separate email app. Donations and community sharing are not active.

**Category suggestion:** Maps & Navigation (review alternatives: Education / Lifestyle)
**Developer display name:** Confirm with Google Play Console
**Support email:** REQUIRED — owner to supply and verify
**Privacy policy URL:** REQUIRED — publish policy at stable public HTTPS URL
**Screenshots:** REQUIRED — capture from running, tested Android app, not concept art
**Feature graphic:** REQUIRED — 1024×500 PNG/JPG, truthful to product
**Icon:** 512×512 PNG, confirm likeness/photo rights and readable small-size treatment
