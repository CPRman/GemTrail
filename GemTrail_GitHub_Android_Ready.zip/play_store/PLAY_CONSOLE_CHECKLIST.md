# Google Play release checklist — GemTrail

## Prepared in source
- [x] App display label GemTrail; package ID com.gemstonewood.app (must verify this is not already used by another Play app).
- [x] Compile/target SDK 36; versionCode 12, versionName 1.2.0.
- [x] GitHub Actions workflow to build a debug APK and unsigned release AAB.
- [x] Draft listing and draft privacy policy.
- [x] Disabled Android Auto Backup to reduce accidental backup of sensitive coordinates.

## Still required before uploading
- [ ] Verify developer account status and policy warnings in Google Play Console (not accessible from source project).
- [ ] Confirm app package ID and developer name, unique Play app creation.
- [ ] Produce signed release AAB with a securely managed upload key and Play App Signing. Never commit keystore or passwords.
- [ ] Run actual build and Android 16 device/emulator tests; fix compile errors and UX issues.
- [ ] Publish privacy policy to public HTTPS URL and supply support email.
- [ ] Review and complete Data safety, app access, content rating, target audience, ads, permissions, and any required government disclosures.
- [ ] Create accurate 512px icon, 1024x500 feature graphic, and actual screenshots from tested build.
- [ ] Validate policy compliance for child-directed educational content and donation language.
- [ ] Create internal test track; run tests; meet any production access testing requirements applicable to account.
- [ ] Review final store listing and submit only after approval.

## Release safety
Unsigned AAB from workflow is not ready for direct Play upload. No store upload, account verification, payments, or publication was performed.
