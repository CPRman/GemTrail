# Build Gem Stone Wood APK

This is source code, not an APK. It has not been compiled or tested on a device in this environment.

## Android Studio
1. Unzip and open `GemStoneWood_Android` in Android Studio.
2. Install Android SDK Platform 35, build tools 35 and JDK 17.
3. Allow Gradle sync; the project uses Android Gradle Plugin 8.7.3.
4. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Debug APK will be at `app/build/outputs/apk/debug/app-debug.apk`.

## GitHub Actions (no local Android SDK needed)
1. Create a **private** GitHub repository and upload the **contents** of `GemStoneWood_Android` to its root, including `.github/workflows/android-apk.yml`.
2. Open the repository's Actions tab, choose **Build Gem Stone Wood Android APK**, and click **Run workflow**.
3. Download the `GemStoneWood-debug-apk` artifact from the successful run.
4. Extract the artifact ZIP to obtain `app-debug.apk`; install on your Android device only if you trust the source and build.

GitHub Actions runs in your own GitHub account and needs a network connection to download Gradle and SDK dependencies. No release signing is configured. This is a debug-only APK, not a Play Store release.

## Features and limitations
- Portrait-oriented native Android Java app.
- Faceted crystal drawing with scalable Android Canvas, not true physically rendered crystal glass.
- Etsy button opens the official Gemstonewoodcom shop in a browser; no live product grid.
- Waypoints are stored only on device. No automatic GPS capture, cloud sync, community submissions or map overlays yet.
- Map button opens Google Maps externally.
