package com.gemstonewood.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.net.Uri;
import android.location.Location;
import android.location.LocationManager;
import android.location.LocationListener;
import android.content.pm.PackageManager;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashSet;
import android.view.*;
import android.widget.*;
import org.json.*;

public class MainActivity extends Activity {
  private static final int IMPORT_CSV_REQUEST = 701;
  private static final int GPS_PERMISSION_REQUEST = 702;
  private LocationManager gpsManager;
  private LocationListener gpsListener;
  private final int forest=Color.rgb(8,42,42), gold=Color.rgb(228,195,122), cream=Color.rgb(6,29,35);
  private LinearLayout root, body, nav;
  private final String shop="https://www.etsy.com/shop/Gemstonewoodcom?sort_order=date_desc";
  private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+0.5f);}
  // Drawn with native Canvas so the crystal bevel scales sharply at every phone density.
  private class FacetedCrystal extends Drawable {
    private final boolean bright;
    private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);
    FacetedCrystal(boolean bright){this.bright=bright;}
    private void polygon(Canvas c,int color,float... xy){
      Path path=new Path();path.moveTo(xy[0],xy[1]);
      for(int i=2;i<xy.length;i+=2)path.lineTo(xy[i],xy[i+1]);
      path.close();p.setColor(color);p.setStyle(Paint.Style.FILL);c.drawPath(path,p);
    }
    @Override public void draw(Canvas canvas){
      android.graphics.Rect b=getBounds();float w=b.width(),h=b.height();
      if(w<=0||h<=0)return;
      canvas.save();canvas.translate(b.left,b.top);
      p.setStyle(Paint.Style.FILL);
      p.setShader(new android.graphics.LinearGradient(0,0,w,h,
        bright?new int[]{0xDCE6F7F7,0xB978ADB4,0xD20A3439}:new int[]{0xBF86B8BF,0xA32B626B,0xDC082E39},
        null,android.graphics.Shader.TileMode.CLAMP));
      canvas.drawRoundRect(new RectF(0,0,w,h),dp(14),dp(14),p);p.setShader(null);
      float e=Math.min(dp(14),Math.min(w,h)*.12f);
      polygon(canvas,0xA5E9FFFF,0,0,w,0,w-e,e,e,e);
      polygon(canvas,0x6CA4D8F0,0,0,e,e,e,h-e,0,h);
      polygon(canvas,0x9584C6DB,w,0,w,h,w-e,h-e,w-e,e);
      polygon(canvas,0x85F4FDFF,0,h,e,h-e,w-e,h-e,w,h);
      polygon(canvas,0x77FFFFFF,0,0,e,e,0,h);
      polygon(canvas,0x55E7F6FF,w,0,w-e,e,w,h);
      p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(1));p.setColor(0xE4E6FCFF);
      canvas.drawRoundRect(new RectF(dp(1),dp(1),w-dp(1),h-dp(1)),dp(14),dp(14),p);
      p.setColor(0x60FFFFFF);canvas.drawLine(e,e,w-e,e,p);
      canvas.restore();
    }
    @Override public void setAlpha(int alpha){}
    @Override public void setColorFilter(android.graphics.ColorFilter filter){}
    @Override public int getOpacity(){return PixelFormat.TRANSLUCENT;}
  }
  private void applyCrystal(View v,boolean bright){
    v.setBackground(new FacetedCrystal(bright));
    v.setElevation(dp(4));
  }
  @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(0xFF08242A);getWindow().setNavigationBarColor(0xFF08242A);show("Home");}
  private TextView text(String s,int size,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextColor(0xFFF2FCFA);t.setTextSize(size);t.setPadding(dp(12),dp(12),dp(12),dp(12));if(bold)t.setTypeface(Typeface.SERIF,Typeface.BOLD);return t;}
  private void section(String s){TextView t=text(s,23,true);t.setTextColor(gold);body.addView(t);}
  private void paragraph(String s){TextView t=text(s,16,false);body.addView(t);}
  private void button(String label,Runnable action){TextView b=text(label+"  ❯",16,true);b.setGravity(Gravity.CENTER);applyCrystal(b,false);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(55));lp.setMargins(0,dp(7),0,dp(7));body.addView(b,lp);b.setOnClickListener(v->action.run());}
  private void tile(LinearLayout row,String symbol,String label,String detail,Runnable action){
    LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setGravity(Gravity.CENTER);applyCrystal(card,false);
    TextView ico=text(symbol,29,true);ico.setTextColor(0xFFDBF8FF);ico.setGravity(Gravity.CENTER);ico.setPadding(0,dp(4),0,0);card.addView(ico);
    TextView title=text(label,17,true);title.setGravity(Gravity.CENTER);title.setPadding(dp(3),0,dp(3),0);card.addView(title);
    TextView sub=text(detail,11,false);sub.setTextColor(gold);sub.setGravity(Gravity.CENTER);sub.setPadding(dp(4),0,dp(4),dp(6));card.addView(sub);
    LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(145),1);lp.setMargins(dp(4),dp(5),dp(4),dp(5));row.addView(card,lp);card.setContentDescription(label+". "+detail);card.setOnClickListener(v->action.run());
  }
  private void link(String url){try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)));}catch(Exception e){new AlertDialog.Builder(this).setMessage("No browser or map app available.").setPositiveButton("OK",null).show();}}
  private void show(String tab){
    root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{0xFF102F39,0xFF03151C,0xFF14504E}));setContentView(root);
    LinearLayout headerBox=new LinearLayout(this);headerBox.setOrientation(LinearLayout.VERTICAL);headerBox.setGravity(Gravity.CENTER);applyCrystal(headerBox,true);
    LinearLayout.LayoutParams hl=new LinearLayout.LayoutParams(-1,dp(102));hl.setMargins(dp(12),dp(12),dp(12),dp(5));root.addView(headerBox,hl);
    TextView header=text("◇ GEMTRAIL ◇",25,true);header.setTextColor(0xFFF4FFFF);header.setGravity(Gravity.CENTER);headerBox.addView(header);
    TextView tagline=text("by Gem Stone Wood · Every Stone Has a Story",13,false);tagline.setTextColor(0xFF233B32);tagline.setGravity(Gravity.CENTER);tagline.setPadding(0,0,0,dp(8));headerBox.addView(tagline);
    ScrollView scroll=new ScrollView(this);scroll.setFillViewport(false);body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setPadding(dp(10),dp(5),dp(10),dp(24));scroll.addView(body);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
    nav=new LinearLayout(this);nav.setGravity(Gravity.CENTER);applyCrystal(nav,false);LinearLayout.LayoutParams nl=new LinearLayout.LayoutParams(-1,dp(62));nl.setMargins(dp(8),0,dp(8),dp(6));root.addView(nav,nl);
    for(String name:new String[]{"Home","Map","Finds","Kids","Shop"}){TextView n=text(name,12,true);n.setTextColor(name.equals(tab)?gold:0xFFE2F7F5);n.setGravity(Gravity.CENTER);n.setPadding(0,dp(12),0,dp(12));nav.addView(n,new LinearLayout.LayoutParams(0,-2,1));n.setContentDescription("Navigate to "+name);n.setOnClickListener(v->show(name));}
    switch(tab){case "Map":map();break;case "Finds":finds();break;case "Kids":kids();break;case "Shop":shop();break;default:home();}
  }
  private void home(){
    TextView intro=text("Explore Earth's treasures",18,true);intro.setTextColor(gold);intro.setGravity(Gravity.CENTER);body.addView(intro);
    String[][] tiles={{"⌖","Mineral Map","Explore locations"},{"◇","Identify Minerals","Guides & info"},{"♧","Etsy Shop","Jade & gemstones"},{"✦","UV Minerals","Fluorescent treasures"},{"⚑","My Finds","Save your waypoints"},{"✧","Rocks for Kids","Learn & discover"}};
    for(int i=0;i<6;i+=2){LinearLayout row=new LinearLayout(this);body.addView(row);final int first=i;tile(row,tiles[i][0],tiles[i][1],tiles[i][2],()->openTile(first));tile(row,tiles[i+1][0],tiles[i+1][1],tiles[i+1][2],()->openTile(first+1));}
    button("The Prospector  ·  Jade Master  ·  Mining Claim Owner",this::showFounder);
    button("♥ Support GemTrail development",this::donate);
    button("♧ Trail Friends — invite a rockhound",this::friends);
  }
  private boolean validFriendEmail(String email){
    return android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches() && !email.contains("\n") && !email.contains("\r");
  }
  private void emailFriend(String address, boolean invite){
    Intent email=new Intent(Intent.ACTION_SENDTO,Uri.parse("mailto:"+Uri.encode(address)));
    email.putExtra(Intent.EXTRA_SUBJECT,invite?"Join me on GemTrail":"Hello from GemTrail");
    email.putExtra(Intent.EXTRA_TEXT,invite?
      "Join me exploring rocks and minerals with GemTrail by Gem Stone Wood! App availability coming soon.":
      "Hi! Want to plan a rockhounding trip? Sent using GemTrail by Gem Stone Wood.");
    try{startActivity(Intent.createChooser(email,"Choose your email app"));}
    catch(android.content.ActivityNotFoundException e){Toast.makeText(this,"Install or configure an email app",Toast.LENGTH_LONG).show();}
  }
  private void friends(){
    body.removeAllViews();section("Trail Friends — Email");
    paragraph("Email friends using your phone's email app. Messages are only sent when you review and send them. No private GPS coordinates are included.");
    EditText entry=new EditText(this);entry.setSingleLine(true);
    entry.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
    entry.setHint("Friend's email address");body.addView(entry);
    button("Invite by email",()->{String e=entry.getText().toString().trim();if(validFriendEmail(e))emailFriend(e,true);else Toast.makeText(this,"Enter a valid email",Toast.LENGTH_SHORT).show();});
    button("Save email contact",()->{
      String email=entry.getText().toString().trim();if(!validFriendEmail(email)){Toast.makeText(this,"Enter a valid email",Toast.LENGTH_SHORT).show();return;}
      try{JSONArray a=new JSONArray(getPreferences(0).getString("friend_emails","[]"));
        for(int i=0;i<a.length();i++)if(email.equalsIgnoreCase(a.optString(i))){Toast.makeText(this,"Already saved",Toast.LENGTH_SHORT).show();return;}
        a.put(email);getPreferences(0).edit().putString("friend_emails",a.toString()).apply();friends();
      }catch(Exception e){Toast.makeText(this,"Could not save",Toast.LENGTH_SHORT).show();}
    });
    section("Saved email contacts (on this device)");
    try{JSONArray a=new JSONArray(getPreferences(0).getString("friend_emails","[]"));
      for(int i=0;i<a.length();i++){final String address=a.optString(i);
        button("Email "+address,()->emailFriend(address,false));
        button("Remove "+address,()->{
          try{JSONArray old=new JSONArray(getPreferences(0).getString("friend_emails","[]")),next=new JSONArray();
            for(int j=0;j<old.length();j++)if(!address.equalsIgnoreCase(old.optString(j)))next.put(old.getString(j));
            getPreferences(0).edit().putString("friend_emails",next.toString()).apply();friends();
          }catch(Exception ignored){}
        });
      }
    }catch(Exception ignored){}
    paragraph("Requires a configured email app and internet to deliver. No in-app inbox, background email sending, contact uploads, or automatic location sharing.");
    button("Back to home",()->show("Home"));
  }
  private void donate(){
    body.removeAllViews();
    section("♥ Support GemTrail");
    paragraph("Help keep the adventure growing! GemTrail by Gem Stone Wood is being developed for rockhounds, mineral collectors, and families.");
    section("Your support helps build");
    paragraph("• Downloadable offline topographic maps\\n• Private GPS prospecting tools\\n• Mineral and UV identification guides\\n• Moderated community discoveries\\n• Rocks for Kids activities");
    section("Contributions — coming soon");
    paragraph("Secure payment options will be enabled after approved Google Play payment integration is configured. This version does not accept or process donations.");
    paragraph("Contributions will be optional and are not tax-deductible charitable gifts. All app features remain accessible without contributing.");
    button("Back to home",()->show("Home"));
  }
  private void showFounder(){body.removeAllViews();section("The Prospector");paragraph("Founder of Gem Stone Wood\nJade Master • Mining Claim Owner\nTreasures from Earth and Water");button("Back to home",()->show("Home"));}
  private void openTile(int i){switch(i){case 0:show("Map");break;case 1:showGuide();break;case 2:show("Shop");break;case 3:showUV();break;case 4:show("Finds");break;default:show("Kids");}}
  private void showGuide(){body.removeAllViews();section("Mineral identification");paragraph("Nephrite jade: tough, interlocking amphibole mineral, often green.\n\nQuartz: hardness 7, glassy luster.\n\nCalcite: hardness 3; often reacts with dilute acid.\n\nColor alone is not enough for reliable identification.");button("Back to home",()->show("Home"));}
  private void showUV(){body.removeAllViews();section("UV minerals");paragraph("Some minerals fluoresce under ultraviolet light. Different wavelengths can reveal different colors. Use UV-rated eye protection and never shine UV light into eyes.");button("Browse UV minerals on Etsy",()->link(shop));button("Back to home",()->show("Home"));}
  // Offline coordinate plot: does not use internet or map tiles.
  private void offlinePlot(){
    body.removeAllViews();
    section("Offline mineral waypoint plot");
    paragraph("Works without cellular data. Shows locally saved coordinates on a grid, NOT terrain, roads, or an offline topographic map. GPS positioning is available from the My Finds screen.");
    ArrayList<JSONObject> points=new ArrayList<>();
    try{
      JSONArray a=new JSONArray(getPreferences(0).getString("finds","[]"));
      for(int i=0;i<a.length();i++){
        JSONObject o=a.getJSONObject(i);
        double lat=Double.parseDouble(o.optString("lat")),lon=Double.parseDouble(o.optString("lon"));
        if(lat>=-90&&lat<=90&&lon>=-180&&lon<=180)points.add(o);
      }
    }catch(Exception ignored){}
    View plot=new View(this){
      Paint paint=new Paint(3);
      @Override protected void onDraw(Canvas c){
        super.onDraw(c);float w=getWidth(),h=getHeight();
        c.drawColor(0xFF092A2D);paint.setColor(0x4455FFFF);paint.setStrokeWidth(dp(1));
        for(int i=1;i<10;i++){c.drawLine(w*i/10,0,w*i/10,h,paint);c.drawLine(0,h*i/10,w,h*i/10,paint);}
        if(points.isEmpty())return;
        double minLat=90,maxLat=-90,minLon=180,maxLon=-180;
        for(JSONObject o:points){double a=o.optDouble("lat"),b=o.optDouble("lon");minLat=Math.min(minLat,a);maxLat=Math.max(maxLat,a);minLon=Math.min(minLon,b);maxLon=Math.max(maxLon,b);}
        minLat-=0.001;maxLat+=0.001;minLon-=0.001;maxLon+=0.001;
        paint.setTextSize(dp(11));
        for(JSONObject o:points){
          float x=dp(22)+(w-dp(44))*(float)((o.optDouble("lon")-minLon)/(maxLon-minLon));
          float y=dp(22)+(h-dp(44))*(float)((maxLat-o.optDouble("lat"))/(maxLat-minLat));
          paint.setColor(0xFF52EFFF);c.drawCircle(x,y,dp(5),paint);
          paint.setColor(Color.WHITE);c.drawText(o.optString("name"),x+dp(7),y-dp(7),paint);
        }
      }
    };
    body.addView(plot,new LinearLayout.LayoutParams(-1,dp(370)));
    button("Return to map options",()->show("Map"));
  }
  private void map(){section("Mineral discovery map");button("Offline waypoint plot (no internet)",this::offlinePlot);paragraph("Open a map to explore your area. Your saved finds appear in the Finds tab. Map imports and community-shared pins will be added when connected to a map service and backend.");button("Open Google Maps",()->link("https://www.google.com/maps"));button("Record GPS coordinates",()->show("Finds"));button("View saved waypoints",()->show("Finds"));paragraph("Privacy: never publish private property, protected sites, or sensitive collection locations without permission.");}
  private void finds(){section("My mineral finds");paragraph("Finds are saved locally on this device. They are not public or synchronized.");button("+ Add a waypoint",this::addFind);button("◎ Capture current GPS location (offline)",this::captureGps);button("Share waypoints as CSV",this::shareFinds);button("Import waypoints from CSV",this::pickCsv);try{JSONArray a=new JSONArray(getPreferences(0).getString("finds","[]"));if(a.length()==0)paragraph("No finds saved yet.");for(int i=a.length()-1;i>=0;i--){JSONObject o=a.getJSONObject(i);paragraph("✦ "+o.optString("name")+"\n"+o.optString("notes")+"\n"+o.optString("lat")+", "+o.optString("lon"));String lat=o.optString("lat"),lon=o.optString("lon");button("View waypoint #"+(i+1),()->link("https://www.google.com/maps/search/?api=1&query="+Uri.encode(lat+","+lon)));}}catch(Exception e){paragraph("Could not read saved finds.");}}
  private void pickCsv(){
    Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT);
    intent.addCategory(Intent.CATEGORY_OPENABLE);
    intent.setType("*/*");
    intent.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"text/csv","text/comma-separated-values","text/plain","application/octet-stream"});
    try{startActivityForResult(intent,IMPORT_CSV_REQUEST);}catch(Exception e){Toast.makeText(this,"No file picker available",Toast.LENGTH_LONG).show();}
  }
  @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
    super.onActivityResult(requestCode,resultCode,data);
    if(requestCode!=IMPORT_CSV_REQUEST||resultCode!=RESULT_OK||data==null||data.getData()==null)return;
    try(InputStream input=getContentResolver().openInputStream(data.getData());ByteArrayOutputStream output=new ByteArrayOutputStream()){
      if(input==null)throw new Exception("Unable to read file");
      byte[] buffer=new byte[8192];int count;int total=0;
      while((count=input.read(buffer))!=-1){total+=count;if(total>2_000_000)throw new Exception("CSV exceeds 2 MB");output.write(buffer,0,count);}
      String csv=new String(output.toByteArray(),StandardCharsets.UTF_8);
      int imported=importCsv(csv);
      new AlertDialog.Builder(this).setTitle("Waypoint import")
        .setMessage("Imported "+imported+" new valid waypoint(s). Invalid or duplicate rows were skipped. Locations remain private on this device.")
        .setPositiveButton("OK",(d,w)->show("Finds")).show();
    }catch(Exception e){new AlertDialog.Builder(this).setTitle("Import failed").setMessage(e.getMessage()).setPositiveButton("OK",null).show();}
  }
  // Handles quoted commas, escaped quotes, and newlines in CSV fields.
  private ArrayList<ArrayList<String>> parseCsv(String input){
    ArrayList<ArrayList<String>> rows=new ArrayList<>();ArrayList<String> row=new ArrayList<>();StringBuilder field=new StringBuilder();boolean quoted=false;
    for(int i=0;i<input.length();i++){
      char ch=input.charAt(i);
      if(ch=='\"'){
        if(quoted&&i+1<input.length()&&input.charAt(i+1)=='\"'){field.append('\"');i++;}
        else quoted=!quoted;
      }else if(ch==','&&!quoted){row.add(field.toString());field.setLength(0);}
      else if((ch=='\n'||ch=='\r')&&!quoted){
        if(ch=='\r'&&i+1<input.length()&&input.charAt(i+1)=='\n')i++;
        row.add(field.toString());field.setLength(0);
        if(row.size()>1||!row.get(0).trim().isEmpty())rows.add(row);
        row=new ArrayList<>();
      }else field.append(ch);
    }
    if(quoted)throw new IllegalArgumentException("CSV contains an unclosed quoted field");
    row.add(field.toString());if(row.size()>1||!row.get(0).trim().isEmpty())rows.add(row);
    return rows;
  }
  private int importCsv(String csv)throws Exception{
    ArrayList<ArrayList<String>> rows=parseCsv(csv);JSONArray existing=new JSONArray(getPreferences(0).getString("finds","[]"));
    HashSet<String> keys=new HashSet<>();
    for(int i=0;i<existing.length();i++){
      JSONObject item=existing.getJSONObject(i);
      keys.add(item.optString("name").trim().toLowerCase(java.util.Locale.ROOT)+"|"+item.optDouble("lat")+"|"+item.optDouble("lon"));
    }
    int added=0;
    for(int i=0;i<rows.size();i++){
      ArrayList<String> cells=rows.get(i);if(cells.size()<4)continue;
      if(i==0&&cells.get(2).trim().equalsIgnoreCase("latitude"))continue;
      try{
        String name=cells.get(0).trim();double lat=Double.parseDouble(cells.get(2).trim());double lon=Double.parseDouble(cells.get(3).trim());
        if(name.isEmpty()||!Double.isFinite(lat)||!Double.isFinite(lon)||lat < -90||lat > 90||lon < -180||lon > 180)continue;
        String key=name.toLowerCase(java.util.Locale.ROOT)+"|"+lat+"|"+lon;if(!keys.add(key))continue;
        JSONObject item=new JSONObject();item.put("name",name);item.put("mineral",cells.get(1));item.put("lat",lat);item.put("lon",lon);item.put("notes",cells.size()>4?cells.get(4):"");
        existing.put(item);added++;
      }catch(Exception ignored){}
    }
    getPreferences(0).edit().putString("finds",existing.toString()).apply();return added;
  }
  private String csvField(String value){return "\""+value.replace("\"","\"\"")+"\"";}
  private void shareFinds(){
    try{
      JSONArray a=new JSONArray(getPreferences(0).getString("finds","[]"));
      StringBuilder csv=new StringBuilder("name,mineral,latitude,longitude,notes\n");
      for(int i=0;i<a.length();i++){
        JSONObject o=a.getJSONObject(i);
        csv.append(csvField(o.optString("name"))).append(",").append(csvField(o.optString("mineral")))
          .append(",").append(o.optDouble("lat")).append(",").append(o.optDouble("lon"))
          .append(",").append(csvField(o.optString("notes"))).append("\n");
      }
      Intent send=new Intent(Intent.ACTION_SEND);
      send.setType("text/plain");send.putExtra(Intent.EXTRA_SUBJECT,"GemTrail private waypoints.csv");
      send.putExtra(Intent.EXTRA_TEXT,csv.toString());
      startActivity(Intent.createChooser(send,"Share private waypoints"));
    }catch(Exception e){Toast.makeText(this,"Could not export waypoints",Toast.LENGTH_LONG).show();}
  }
  private void captureGps(){
    if(checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED){
      requestPermissions(new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION},GPS_PERMISSION_REQUEST);return;
    }
    try{
      gpsManager=(LocationManager)getSystemService(LOCATION_SERVICE);
      if(gpsManager==null||!gpsManager.isProviderEnabled(LocationManager.GPS_PROVIDER)){
        new AlertDialog.Builder(this).setMessage("Enable GPS / Location in device settings. Satellite GPS works without mobile data, but needs an outdoor sky view.").setPositiveButton("OK",null).show();return;
      }
      Toast.makeText(this,"Waiting for satellite GPS fix…",Toast.LENGTH_LONG).show();
      if(gpsListener!=null)gpsManager.removeUpdates(gpsListener);
      gpsListener=new LocationListener(){
        @Override public void onLocationChanged(Location location){
          if(location==null||!location.hasAccuracy()||location.getAccuracy()>100)return;
          gpsManager.removeUpdates(this);gpsListener=null;
          runOnUiThread(()->addFindAt(location.getLatitude(),location.getLongitude(),location.getAccuracy()));
        }
      };
      gpsManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,1500,0,gpsListener);
    }catch(SecurityException e){Toast.makeText(this,"GPS permission required",Toast.LENGTH_LONG).show();}
  }
  @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] results){
    super.onRequestPermissionsResult(requestCode,permissions,results);
    if(requestCode==GPS_PERMISSION_REQUEST&&results.length>0&&results[0]==PackageManager.PERMISSION_GRANTED)captureGps();
  }
  @Override protected void onDestroy(){
    if(gpsManager!=null&&gpsListener!=null)try{gpsManager.removeUpdates(gpsListener);}catch(SecurityException ignored){}
    super.onDestroy();
  }
  private void addFindAt(double lat,double lon,float accuracy){
    addFind(Double.toString(lat),Double.toString(lon),"GPS accuracy ±"+Math.round(accuracy)+" m; confirm safe collecting access.");
  }
  private void addFind(){addFind("","","");}
  private void addFind(String presetLat,String presetLon,String presetNotes){LinearLayout f=new LinearLayout(this);f.setOrientation(LinearLayout.VERTICAL);f.setPadding(25,10,25,10);EditText[] fields=new EditText[4];String[] labels={"Mineral or location name","Latitude (decimal)","Longitude (decimal)","Notes (optional)"};for(int i=0;i<4;i++){fields[i]=new EditText(this);fields[i].setHint(labels[i]);fields[i].setSingleLine(i!=3);f.addView(fields[i]);}
    fields[1].setText(presetLat);fields[2].setText(presetLon);fields[3].setText(presetNotes);
    new AlertDialog.Builder(this).setTitle("Save a mineral find").setView(f).setNegativeButton("Cancel",null).setPositiveButton("Save",(d,w)->{try{String name=fields[0].getText().toString().trim();double lat=Double.parseDouble(fields[1].getText().toString().trim()),lon=Double.parseDouble(fields[2].getText().toString().trim());if(name.isEmpty()||lat < -90||lat > 90||lon < -180||lon > 180)throw new Exception();JSONArray a=new JSONArray(getPreferences(0).getString("finds","[]"));JSONObject o=new JSONObject();o.put("name",name);o.put("lat",lat);o.put("lon",lon);o.put("notes",fields[3].getText().toString());a.put(o);getPreferences(0).edit().putString("finds",a.toString()).apply();show("Finds");}catch(Exception e){Toast.makeText(this,"Enter a name and valid coordinates.",Toast.LENGTH_LONG).show();}}).show();}
  private void kids(){section("Rocks for Kids");paragraph("Explore • Learn • Collect responsibly");section("Rock detective");paragraph("Look at color, streak, luster, and crystal shape. Color alone rarely identifies a mineral.");section("Three easy experiments");paragraph("1. Compare a rock's hardness using a copper coin (with adult help).\n2. Shine a safe visible flashlight through translucent stones.\n3. Draw a rock and label its textures.");section("Safety first");paragraph("Ask an adult before collecting. Never taste minerals, enter abandoned mines, or shine UV light into eyes. Wash hands after handling specimens.");}
  private void shop(){section("Shop Gem Stone Wood");paragraph("Browse our latest jade, mineral, and jewelry listings on Etsy. Prices and availability are managed by Etsy.");button("Browse newest Etsy listings ↗",()->link(shop));button("Open Gemstonewoodcom shop ↗",()->link("https://www.etsy.com/shop/Gemstonewoodcom"));paragraph("Purchases and checkout take place securely on Etsy. A live in-app product grid requires authorized Etsy listing data and is not yet enabled.");}
}
