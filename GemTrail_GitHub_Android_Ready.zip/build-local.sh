#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if ! command -v gradle >/dev/null; then echo 'Gradle is required (or use the GitHub Actions workflow).' >&2; exit 2; fi
if ! command -v java >/dev/null; then echo 'JDK 17 required.' >&2; exit 2; fi
gradle --no-daemon lintDebug testDebugUnitTest assembleDebug bundleRelease
printf '\nDebug APK: app/build/outputs/apk/debug/app-debug.apk\nUnsigned release AAB: app/build/outputs/bundle/release/app-release.aab\n'
