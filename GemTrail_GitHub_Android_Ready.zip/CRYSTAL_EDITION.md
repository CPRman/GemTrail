# Crystal Edition v0.2

Native portrait-first Android UI, with two-column crystal-glass tiles, layered beveled borders, restrained optical gradients, and a five-tab bottom navigation. Includes local waypoint journal, mineral guides, Rocks for Kids, UV safety, and Etsy shop link.

The reference artwork is a visual target, not a screenshot of the compiled app. This source implements the crystal treatment using Android drawables without requiring a heavy background bitmap.

Build: open this folder in Android Studio and build the `app` module. Not compiled or tested on a device in this environment.

Limitations: Google Maps and Etsy open externally; community waypoint synchronization and Etsy listing API integration are not yet implemented.
