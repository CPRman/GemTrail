#!/usr/bin/env python3
"""Fast source validation before Android SDK build."""
from pathlib import Path
import re, xml.etree.ElementTree as ET
root=Path(__file__).resolve().parents[1]
manifest=root/'app/src/main/AndroidManifest.xml'
ET.parse(manifest)
source=(root/'app/src/main/java/com/gemstonewood/app/MainActivity.java').read_text()
assert 'class MainActivity extends Activity' in source
assert 'offlinePlot()' in source and 'body.removeAllViews();' in source.split('private void offlinePlot(){',1)[1].split('section(',1)[0]
gradle=(root/'app/build.gradle').read_text()
assert re.search(r'targetSdk\s+36',gradle)
assert 'android:allowBackup="false"' in manifest.read_text()
assert (root/'app/src/main/res/mipmap-xxxhdpi/ic_launcher.png').exists()
print('Static Android project checks passed. This is NOT a compilation.')
