# Gem Stone Wood Android — native MVP v0.1

A clean native Android Java project. Open this folder in Android Studio, allow Gradle sync, and choose **Build > Build APK(s)**. Requires Android SDK 35, JDK 17 and internet access for initial Android Gradle Plugin download. Minimum Android 8.0.

## Included
- Forest-green/gold Android navigation
- Home and mineral identification guide
- Mineral map launcher (Google Maps)
- Local waypoint journal with name, coordinates, notes and map launch
- Rocks for Kids safety and activities
- Etsy storefront launcher for `Gemstonewoodcom` (newest-first)
- Founder bio

## Not yet implemented
- Verified live Etsy product feed (requires Etsy API authorization / backend)
- Community waypoint submissions, moderation, cloud synchronization
- Google Maps waypoint import or in-app interactive map (requires maps integration)
- User accounts, photo uploads, push notifications, production privacy policy

No APK was built in this environment because the Android SDK/Gradle tooling is not installed. This is a working source-code starter intended for Android Studio, not a production release. Coordinates are entered manually; all finds remain on-device.
