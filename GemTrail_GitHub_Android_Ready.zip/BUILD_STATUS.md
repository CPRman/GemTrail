# Crystal Edition v0.4 build status

Native Android Java source project, portrait orientation.

## Implemented
- Responsive two-column home menu with Canvas-rendered, faceted, translucent crystal bevels.
- Bottom navigation, Etsy storefront links, mineral guide, UV safety, Rocks for Kids, founder profile.
- Local mineral waypoint journal (name, coordinates, notes) and open waypoint in Maps.

## Not yet implemented
- True optical refraction of background images, live Etsy catalog, waypoint import, shared community backend.
- APK compilation or device testing. Android SDK and Gradle are unavailable in this environment.

## Build in Android Studio
1. Unzip, then open the GemStoneWood_Android directory.
2. Let Android Studio install Android SDK 35 and sync Gradle (Android Gradle Plugin 8.7.3; JDK 17).
3. Choose Build > Build APK(s).
4. Install the debug APK on an Android device and test all tabs and waypoint saving.

The interface is designed for portrait orientation. Its bevels are native Canvas geometry, not the photorealistic concept art.
