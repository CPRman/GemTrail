# GemTrail Android build handoff (v1.6)

## Local build
Install Android Studio / Android SDK API 36, build tools 36.0.0, JDK 17, and Gradle 8.10.2. From the `Android` directory run `python3 scripts/validate_project.py` and `./build-local.sh`. You may instead import `Android/` into Android Studio and run **Build APK(s)**.

## GitHub Actions
Create a private repository, upload the **contents of the `Android` directory to the repository root**, then open **Actions → Build GemTrail Android and Play bundle → Run workflow**. The workflow uses Gradle 8.10.2, Android SDK 36 and JDK 17. Download `GemTrail-debug-apk` from the successful workflow run and install it on a test device. It also creates an **unsigned** release AAB, which cannot be published until signed.

## Release blockers
1. Build and lint must pass on CI; this environment does not include the Android SDK or Gradle.
2. Test GPS permissions, offline behavior, file import/export, and privacy on a physical phone.
3. Set up a valid Play developer account, create app entry, confirm application ID, sign AAB with a securely stored release key, and complete store declarations.
4. The app still lacks downloadable offline topo maps, real friend backend, and payment collection. Do not advertise these as active features.

## Security
Never commit a release keystore or passwords. App local backups are disabled to help protect private prospecting waypoints.
